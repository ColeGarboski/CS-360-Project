package com.example.colegarboskiproject2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {
    private List<Item> items;
    private Database warehouseDB;
    private SmsNotificationCallback smsCallback;

    public interface SmsNotificationCallback {
        void onLowInventory(String itemName);
    }

    public InventoryAdapter(List<Item> items, Database warehouseDB) {
        this.items = items;
        this.warehouseDB = warehouseDB;
    }

    public InventoryAdapter(List<Item> items, Database warehouseDB,
                            SmsNotificationCallback smsCallback) {
        this.items = items;
        this.warehouseDB = warehouseDB;
        this.smsCallback = smsCallback;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Item item = items.get(position);
        holder.itemNameText.setText(item.getName());
        holder.quantityText.setText(String.valueOf(item.getQuantity()));

        // Increase button
        holder.increaseButton.setOnClickListener(v -> {
            int newQuantity = item.getQuantity() + 1;
            updateItemQuantity(item, newQuantity, holder);
        });

        // Decrease button
        holder.decreaseButton.setOnClickListener(v -> {
            int newQuantity = item.getQuantity() - 1;
            if (newQuantity >= 0) {
                updateItemQuantity(item, newQuantity, holder);
            } else {
                Toast.makeText(v.getContext(), "Quantity cannot be negative",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // Delete button
        holder.deleteButton.setOnClickListener(v -> {
            warehouseDB.deleteItem(item.getName());
            items.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, items.size());
        });
    }

    private void updateItemQuantity(Item item, int newQuantity, ViewHolder holder) {
        // Update database
        int result = warehouseDB.updateItemQuantity(item.getName(), newQuantity);
        if (result > 0) {
            // Update UI
            item.setQuantity(newQuantity);
            holder.quantityText.setText(String.valueOf(newQuantity));

            // Show notification if item is out of stock
            if (newQuantity == 0) {
                Toast.makeText(holder.itemView.getContext(),
                        "Warning: " + item.getName() + " is out of stock!",
                        Toast.LENGTH_LONG).show();
            }

            // Send SMS notification if able
            smsCallback.onLowInventory(item.getName());
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView itemNameText;
        TextView quantityText;
        MaterialButton increaseButton;
        MaterialButton decreaseButton;
        MaterialButton deleteButton;

        ViewHolder(View view) {
            super(view);
            itemNameText = view.findViewById(R.id.itemNameText);
            quantityText = view.findViewById(R.id.quantityText);
            increaseButton = view.findViewById(R.id.increaseButton);
            decreaseButton = view.findViewById(R.id.decreaseButton);
            deleteButton = view.findViewById(R.id.deleteButton);
        }
    }
}