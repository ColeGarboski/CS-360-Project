package com.example.colegarboskiproject2;

import android.Manifest;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_REQUEST_CODE = 123;
    private RecyclerView recyclerView;
    private InventoryAdapter adapter;
    private Database warehouseDB;
    private boolean hasSmsPermission = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Check for SMS permission
        checkSmsPermission();

        // Create database
        warehouseDB = new Database(this);

        recyclerView = findViewById(R.id.inventoryRecyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        // Load items from database
        loadItems();

        // Set up add item button
        findViewById(R.id.addItemButton).setOnClickListener(v -> showAddItemDialog());
    }

    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            // If permission not given, ask for it
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE);
        } else {
            // Permission already given
            hasSmsPermission = true;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            hasSmsPermission = grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED;

            if (hasSmsPermission) {
                Toast.makeText(this, "SMS notifications enabled",
                        Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this,
                        "SMS notifications disabled. App will continue without this feature.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    public void sendLowInventoryNotification(String itemName) {
        if (!hasSmsPermission) {
            return;
        }

        try {
            SmsManager smsManager = SmsManager.getDefault();
            String message = "Low Inventory Alert: " + itemName + " is out of stock!";
            String phoneNumber = "15551234567"; // Emulator's number for testing, need to replace if in production
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS notification",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void loadItems() {
        List<Item> items = warehouseDB.getAllItems();
        adapter = new InventoryAdapter(items, warehouseDB, this::sendLowInventoryNotification);
        recyclerView.setAdapter(adapter);
    }

    private void showAddItemDialog() {
        View formView = LayoutInflater.from(this).inflate(R.layout.form_add_item, null);

        EditText itemNameInput = formView.findViewById(R.id.itemNameInput);
        EditText quantityInput = formView.findViewById(R.id.quantityInput);

        // Show add item form
        new AlertDialog.Builder(this)
                .setTitle("Add New Item")
                .setView(formView)
                .setPositiveButton("Add", (dialog, which) -> {
                    String itemName = itemNameInput.getText().toString().trim();
                    String quantityStr = quantityInput.getText().toString().trim();

                    // Validate inputs
                    if (itemName.isEmpty() || quantityStr.isEmpty()) {
                        Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    try {
                        int quantity = Integer.parseInt(quantityStr);

                        // Add item to database
                        long result = warehouseDB.addItem(itemName, quantity);

                        if (result != -1) {
                            // Successfully added item
                            Toast.makeText(this, "Item added successfully", Toast.LENGTH_SHORT).show();
                            // Reload the items list to show the new item
                            loadItems();
                        } else {
                            Toast.makeText(this, "Error adding item", Toast.LENGTH_SHORT).show();
                        }
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Please enter a valid quantity", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (warehouseDB != null) {
            warehouseDB.close();
        }
    }
}