package com.example.colegarboskiproject2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;
import java.util.ArrayList;
import java.util.List;

public class Database extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "inventory.db";
    private static final int DATABASE_VERSION = 1;

    // Table and column names for Users
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    // Table and column names for Inventory
    private static final String TABLE_INVENTORY = "inventory";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_QUANTITY = "quantity";

    // Create table statements
    private static final String SQL_CREATE_USERS_TABLE =
            "CREATE TABLE " + TABLE_USERS + " (" +
                    BaseColumns._ID + " INTEGER PRIMARY KEY," +
                    COLUMN_USERNAME + " TEXT UNIQUE NOT NULL," +
                    COLUMN_PASSWORD + " TEXT NOT NULL)";

    private static final String SQL_CREATE_INVENTORY_TABLE =
            "CREATE TABLE " + TABLE_INVENTORY + " (" +
                    BaseColumns._ID + " INTEGER PRIMARY KEY," +
                    COLUMN_NAME + " TEXT NOT NULL," +
                    COLUMN_QUANTITY + " INTEGER NOT NULL)";

    // Instance variable for database
    private SQLiteDatabase database;

    public Database(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        database = getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_USERS_TABLE);
        db.execSQL(SQL_CREATE_INVENTORY_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop tables if they exist
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);
    }

    // User functions
    public long addUser(String username, String password) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);
        return database.insert(TABLE_USERS, null, values);
    }

    public boolean checkUser(String username, String password) {
        String[] columns = { COLUMN_USERNAME };
        String selection = COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = { username, password };

        Cursor cursor = database.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // Inventory functions
    public long addItem(String name, int quantity) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_QUANTITY, quantity);
        return database.insert(TABLE_INVENTORY, null, values);
    }

    public List<Item> getAllItems() {
        List<Item> items = new ArrayList<>();

        Cursor cursor = database.query(TABLE_INVENTORY, null, null, null, null, null, null);

        while(cursor.moveToNext()) {
            String name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_QUANTITY));
            items.add(new Item(name, quantity));
        }
        cursor.close();

        return items;
    }

    public int updateItemQuantity(String itemName, int newQuantity) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_QUANTITY, newQuantity);

        String selection = COLUMN_NAME + " = ?";
        String[] selectionArgs = { itemName };

        return database.update(TABLE_INVENTORY, values, selection, selectionArgs);
    }

    public int deleteItem(String itemName) {
        String selection = COLUMN_NAME + " = ?";
        String[] selectionArgs = { itemName };
        return database.delete(TABLE_INVENTORY, selection, selectionArgs);
    }
}