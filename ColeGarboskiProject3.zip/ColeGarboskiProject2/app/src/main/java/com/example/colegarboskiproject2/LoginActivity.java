package com.example.colegarboskiproject2;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;

public class LoginActivity extends AppCompatActivity {
    private Database warehouseDB;
    private EditText usernameInput;
    private EditText passwordInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Create database
        warehouseDB = new Database(this);

        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);

        // Set up login button
        findViewById(R.id.loginButton).setOnClickListener(v -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            // Validate inputs
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Check if user already has account
            if (warehouseDB.checkUser(username, password)) {
                // Login successful
                Intent intent = new Intent(this, InventoryActivity.class);
                startActivity(intent);
                finish();
            } else {
                // Login failed
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }
        });

        // Set up create account button
        findViewById(R.id.createAccountButton).setOnClickListener(v -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            // Validate inputs
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                // Create new account
                long result = warehouseDB.addUser(username, password);
                if (result != -1) {
                    // Account creation successful
                    Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show();
                    // Log in
                    Intent intent = new Intent(this, InventoryActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    // Account creation failed
                    Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, "Error creating account", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Clean up database connection
        if (warehouseDB != null) {
            warehouseDB.close();
        }
    }
}